python pipeline.py ScoreTask --local-scheduler --tweet-file airline_tweets.csv
